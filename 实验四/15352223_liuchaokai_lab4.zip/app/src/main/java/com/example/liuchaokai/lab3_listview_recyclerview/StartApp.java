package com.example.liuchaokai.lab3_listview_recyclerview;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import org.greenrobot.eventbus.EventBus;

public class StartApp extends BroadcastReceiver {

    private String tag = "test";

    @Override
    public void onReceive(Context context, Intent intent) {

        //gbundle接收外部数据
        Bundle gBundle = intent.getExtras();
        int pIcon = gBundle.getInt("pIcon");
        String pTile = gBundle.getString("pTile");
        String pText = gBundle.getString("pText");
        String pName = gBundle.getString("pName");
        //Toast.makeText(context,"Start the App:"+pIcon+pTile+pText,Toast.LENGTH_SHORT).show();

        //获取 NotificationManager对象
        NotificationManager mNotifyManager = (NotificationManager) context
                .getSystemService(Context.NOTIFICATION_SERVICE);
        //实例化Notification.Builde并设置相关属性
        Notification.Builder showProduct = new Notification.Builder(context);
        showProduct.setSmallIcon(pIcon)//设置小图标
                .setLargeIcon(BitmapFactory.decodeResource(context.getResources(),pIcon))//设置大图标
                .setContentTitle(pTile)//设置通知标题
                .setContentText(pText)//设置通知内容
                .setAutoCancel(true)//点击通知后自动清除
                .setDefaults(Notification.DEFAULT_ALL)//设置震动，声音，led等效果
                .setTicker("新品热卖");


        if(intent.getAction().equals("com.example.liuchaokai.lab3_listview_recyclerview.STARTAPP"))
        {
            //通知栏
            Intent intentT = new Intent(context,Shopping.class);
            intentT.putExtra("name",pName);
            PendingIntent pi = PendingIntent.getActivity(context,0,intentT,
                    PendingIntent.FLAG_UPDATE_CURRENT);
            showProduct.setContentIntent(pi);//跳转到ShoppingActivity
            mNotifyManager.notify(0, showProduct.build());//通过builder.build()方法生成Notification对象,并发送通知,id=0
        }
        else if(intent.getAction().equals("Order.Product"))
        {
            int pNumber = gBundle.getInt("sNumber");
            //通知栏
            Intent intentT = new Intent(context,MainActivity.class);
            intentT.putExtra("flag",1);
            PendingIntent pi = PendingIntent.getActivity(context,0,intentT,
                    PendingIntent.FLAG_UPDATE_CURRENT);
            showProduct.setContentIntent(pi);
            mNotifyManager.notify(pNumber+1, showProduct.build());//发送通知,id=pNumber+1
            //发信息
            EventBus.getDefault().post(
                        new SmsEventbus(pName,pNumber));
        }
    }
}

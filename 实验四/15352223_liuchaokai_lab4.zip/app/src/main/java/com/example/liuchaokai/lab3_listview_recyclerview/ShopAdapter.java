package com.example.liuchaokai.lab3_listview_recyclerview;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by liuchaokai on 2017/10/20.
 */

public class ShopAdapter extends ArrayAdapter<Products>
{
    private int resourceId;

    public ShopAdapter(Context context, int textViewResourceId,
                       List<Products> objects)
    {
        super(context,textViewResourceId,objects);
        resourceId = textViewResourceId;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Products products = getItem(position);
        View view;
        ViewHolder viewHolder;

        if(convertView == null)
        {
            view = LayoutInflater.from(getContext()).inflate(resourceId,parent,false);
            viewHolder = new ViewHolder();
            viewHolder.fLetter = (TextView) view.findViewById(R.id.firstletter);
            viewHolder.pName = (TextView) view.findViewById(R.id.productname);
            viewHolder.pPrice = (TextView) view.findViewById(R.id.price);
            view.setTag(viewHolder);
        }
        else
        {
            view = convertView;
            viewHolder = (ViewHolder) view.getTag();
        }
        viewHolder.fLetter.setText(products.getFletter());
        viewHolder.pName.setText(products.getName());
        viewHolder.pPrice.setText(products.getPrice());
        return view;
//        TextView fletter = (TextView) view.findViewById(R.id.firstletter);
//        TextView pname = (TextView) view.findViewById(R.id.productname);
//        TextView pprice = (TextView) view.findViewById(R.id.price);
//        fletter.setText(products.getFletter());
//        pname.setText(products.getName());
//        pprice.setText(products.getPrice());
    }
    private class ViewHolder
    {
        TextView fLetter;
        TextView pName;
        TextView pPrice;
    }
}

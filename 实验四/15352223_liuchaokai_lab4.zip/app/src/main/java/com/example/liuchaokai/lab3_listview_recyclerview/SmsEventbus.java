package com.example.liuchaokai.lab3_listview_recyclerview;


public class SmsEventbus {
    private String msg;
    private int mNumber;
    public SmsEventbus(String msg, int number)
    {
        this.msg=msg;
        this.mNumber = number;
    }
    public String getMsg()
    {
        return msg;
    }
    public int getmNumber()
    {
        return mNumber;
    }
}

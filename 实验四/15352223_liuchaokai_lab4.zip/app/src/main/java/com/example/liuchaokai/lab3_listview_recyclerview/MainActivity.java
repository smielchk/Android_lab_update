package com.example.liuchaokai.lab3_listview_recyclerview;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import jp.wasabeef.recyclerview.adapters.ScaleInAnimationAdapter;
import jp.wasabeef.recyclerview.animators.OvershootInLeftAnimator;

public class MainActivity extends AppCompatActivity {

    private List<Products> productsList = new ArrayList<>();
    private RecyclerView recyclerView;//获取布局实例
    private ProductAdapter productAdapter;

    private List<Products> shopList = new ArrayList<>();
    private ShopAdapter shopAdapter;
    private ListView listView;

    private FloatingActionButton fab;
    private int flag = 0;//标记表示界面的切换。0为商品列表界面，1为购物车界面
    private String sName = "name";
    private int randompNum;

    private String [] Keywords = {"*","E","A","D","K","W","M","F","M","L","B"};
    private String [] Names = {"购物车","Enchated Forest","Arla Milk","Devondale Milk",
            "Kindle Oasis","waitrose 早餐麦片","Mcvitie's 饼干","Ferreo Rocher",
            "Maltesers","Lindt","Borggreve"};
    private String [] Prices = {"价格  ","¥5.00","¥59.00","¥79.00","¥2399.00","¥179.00", "¥14.90",
            "¥132.59","¥141.43","¥139.43","¥28.90"};
    private int pImages [] ={R.drawable.enchatedforest,R.drawable.arla,R.drawable.devondale,
            R.drawable.kindle,R.drawable.waitrose,R.drawable.mcvitie,R.drawable.ferrero,R.drawable.maltesers,
            R.drawable.lindt,R.drawable.borggreve};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //生成随机数
        Random pNumber = new Random();
        randompNum = pNumber.nextInt(10)%10+1;

        //给广播传递数据
        Bundle smsBundle = new Bundle();
        smsBundle.putInt("pIcon",pImages[randompNum-1]);//传递图标
        smsBundle.putString("pTile","新商品热卖");//传递标题
        smsBundle.putString("pText",Names[randompNum]+"仅售"+Prices[randompNum]+'!');//传递内容
        smsBundle.putString("pName",Names[randompNum]);//传递商品名字

        //应用启动广播
        Intent smsintent = new Intent("com.example.liuchaokai.lab3_listview_recyclerview.STARTAPP");
        smsintent.putExtras(smsBundle);
        sendBroadcast(smsintent);

        //注册eventbus
        EventBus.getDefault().register(this);

        initProducts();//初始化产品列表
        initShopcar();//初始化购物车

        //RecyclerView
        recyclerView = (RecyclerView) findViewById(R.id.recyclerview);//获取布局实例
        productAdapter = new ProductAdapter(MainActivity.this,productsList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);//设置布局管理器
        recyclerView.setLayoutManager(layoutManager); //设置为垂直布局，这也是默认的
        //recyclerView.setAdapter(productAdapter);//设置Adapter
        ScaleInAnimationAdapter animationAdapter = new ScaleInAnimationAdapter(productAdapter);
        animationAdapter.setDuration(1000);
        recyclerView.setAdapter(animationAdapter);
        recyclerView.setItemAnimator(new OvershootInLeftAnimator());
        //recyclerView.addItemDecoration( new DividerGridItemDecoration(this ));//设置分隔线
        //recyclerView.setItemAnimator( new DefaultItemAnimator());//设置增加或删除条目的动画

        //ListView
        shopAdapter = new ShopAdapter(MainActivity.this, R.layout.product,shopList);
        listView = (ListView) findViewById(R.id.shoppingcar);
        listView.setAdapter(shopAdapter);
        listView.setVisibility(View.INVISIBLE);//刚开始设置listview不可见

        //recyclerview点击事件
        productAdapter.setOnItemClickListener(new ProductAdapter.OnItemClickListener()
        {
            @Override//短按跳转至商品详情界面
            public void onItemClick(int position) {
                Intent intent = new Intent(MainActivity.this,Shopping.class);
                final Products product = productsList.get(position);
                intent.putExtra(sName,product.getName());//传入数据
                startActivityForResult(intent,1);//1为请求码，需要是唯一值
            }

            @Override//长按删除商品
            public void onItemLongClick(int position) {
                final Products product = productsList.get(position);
                Toast.makeText(MainActivity.this,"移除第"+(position+1)+"个商品",Toast.LENGTH_SHORT).show();
                productsList.remove(product);
                productAdapter.notifyDataSetChanged();
            }
        });

        //listview点击事件
        //短按跳转至商品详情界面
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Products product = shopList.get(position);
                if(position>=1)
                {
                    final Products products = shopList.get(position);
                    Intent intent = new Intent(MainActivity.this,Shopping.class);
                    intent.putExtra(sName,products.getName());
                    startActivityForResult(intent,1);
                }
            }
        });

        //长按弹出对话框选择是否删除商品
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id)
            {
                final Products product = shopList.get(position);
                final AlertDialog.Builder deleteDialog = new AlertDialog.Builder(MainActivity.this);
                deleteDialog.setTitle("移除商品");
                deleteDialog.setMessage("从购物车移除"+product.getName());
                if(position>0)
                {
                    deleteDialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(MainActivity.this,"成功移除商品"+product.getName(),
                                    Toast.LENGTH_SHORT).show();
                            shopList.remove(product);
                            shopAdapter.notifyDataSetChanged();
                        }
                    });

                    deleteDialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(MainActivity.this,"点击了取消",Toast.LENGTH_SHORT).show();
                        }
                    });
                    deleteDialog.show();
                }
                return true;
            }
        });

        //floatingactinbutton
        fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                {
                    if(flag==0) flag = 1;
                    else flag = 0;
                    setUI();
                }
            }
        });
    }

    //接受商品详情界面传回的消息，用于更新购物车列表
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        switch (requestCode)
//        {
//            case 1:
//                if(resultCode == RESULT_OK)
//                {
//                    int returnedData = data.getIntExtra("data_return",0);
//                    //Log.d(tag,"点击了"+returnedData);
//                    Products product = new Products(Keywords[returnedData],
//                            Names[returnedData],Prices[returnedData]);
//                    shopList.add(product);//加入购物车数组
//                    shopAdapter.notifyDataSetChanged();//更新数据
//                }
//                break;
//            default:
//        }
//    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);//反注册EventBus
    }

    //接受商品详情界面传回的消息，用于更新购物车列表
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(SmsEventbus event)
    {
        //String msg = "onEventMainThread收到了消息：" + event.getMsg();
        //Toast.makeText(MainActivity.this,msg,Toast.LENGTH_SHORT).show();
        int pNumber = event.getmNumber();
        Products product = new Products(Keywords[pNumber],
                Names[pNumber],Prices[pNumber]);
        shopList.add(product);//加入购物车数组
        shopAdapter.notifyDataSetChanged();//更新数据
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        flag = intent.getIntExtra("flag",0);
        //Toast.makeText(MainActivity.this,"flag="+flag,Toast.LENGTH_SHORT).show();
        setUI();
    }

    private void initProducts()
    {
        for(int i=1;i<=10;i++)
        {
            Products product = new Products(Keywords[i],Names[i],Prices[i]);
            productsList.add(product);
        }
    }

    private void initShopcar()
    {
        Products product = new Products(Keywords[0],Names[0],Prices[0]);
        shopList.add(product);
    }

    private void setUI()
    {
        if(flag == 1)//切换至购物车界面
        {
            fab.setImageResource(R.drawable.mainpage);
            listView.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.INVISIBLE);
        }
        else//切换回商品列表
        {
            fab.setImageResource(R.drawable.shoplist);
            listView.setVisibility(View.INVISIBLE);
            recyclerView.setVisibility(View.VISIBLE);
        }
    }
}

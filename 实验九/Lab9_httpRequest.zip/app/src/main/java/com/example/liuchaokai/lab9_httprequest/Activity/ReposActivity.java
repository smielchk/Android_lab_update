package com.example.liuchaokai.lab9_httprequest.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.example.liuchaokai.lab9_httprequest.Factory.ServiceFactory;
import com.example.liuchaokai.lab9_httprequest.R;
import com.example.liuchaokai.lab9_httprequest.Service.GithubService;
import com.example.liuchaokai.lab9_httprequest.model.Repos;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class ReposActivity extends AppCompatActivity {

    ProgressBar progressBar;
    ListView listView;
    String Name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_repos);
        initView();//实例化
        SetupListView();//请求数据，设置listView
    }

    void initView()
    {
        progressBar = findViewById(R.id.progress_bar2);
        listView = findViewById(R.id.repos_view);
        Name = getIntent().getStringExtra("login");
    }

    void SetupListView()
    {
        ServiceFactory.createRetrofit("https://api.github.com/")//指定baseUrl,(由于是静态函数，可以用类直接调用)
                .create(GithubService.class)//“使用”我们指定的 Interface,到该URL的指定的“下级目录”去请求数据。
                .getRepos(Name)//指定下级目录的接口为"/users/"+Name+"/repos"
                .observeOn(AndroidSchedulers.mainThread())//observeOn()用于指定的是接收事件的线程，此处为主线程，用于操作UI
                .subscribeOn(Schedulers.newThread())//subscribeOn()用于指定发送事件的线程,此处为子线程，用于做耗时操作
                .subscribe(new Subscriber<List<Repos>>()//指定了接收的对象
                {
                    @Override
                    public void onCompleted() {
                        progressBar.setVisibility(View.GONE);
                        listView.setVisibility(View.VISIBLE);
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        listView.setVisibility(View.VISIBLE);
                        Toast.makeText(ReposActivity.this, "出错!", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onNext(List<Repos> reposList) {//在这里接收数据
                        initListData(reposList);
                    }
                });
    }

    void initListData(List<Repos> reposList)
    {
        List<Map<String, String>> repoListData = new ArrayList<>();
        for (Repos repo : reposList) {
            Map<String, String> temp = new LinkedHashMap<>();
            temp.put("name", repo.getName());
            temp.put("language", repo.getLanguage());
            temp.put("intro", repo.getDescription());
            repoListData.add(temp);
        }
        SimpleAdapter simpleAdapter = new SimpleAdapter(this,repoListData,
                R.layout.repositoryitem,
                new String[]{"name", "language", "intro"},
                new int[]{R.id.rname, R.id.language, R.id.intro});
        listView.setAdapter(simpleAdapter);
    }
}

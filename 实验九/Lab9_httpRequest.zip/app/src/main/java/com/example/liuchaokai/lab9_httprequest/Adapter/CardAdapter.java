package com.example.liuchaokai.lab9_httprequest.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.example.liuchaokai.lab9_httprequest.R;
import com.example.liuchaokai.lab9_httprequest.model.Github;

import java.util.List;
public class CardAdapter extends RecyclerView.Adapter<CardAdapter.ViewHolder>
{
    private List<Github> githubList;
    private Context context;
    private LayoutInflater inflater;
    private OnItemClickListener mItemClickListener;

    //类构造函数
    public CardAdapter (Context context, List<Github> githubList)
    {
        this.context = context;
        this.githubList = githubList;
        inflater = LayoutInflater.from(context);
        mItemClickListener = null;
    }
    //定义内部类继承于RecyclerView.ViewHolder
    static class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView Login;
        TextView Id;
        TextView Blog;
        private ViewHolder(View view)
        {
            super(view);
            Login = (TextView) view.findViewById(R.id.login);
            Id = (TextView) view.findViewById(R.id.id);
            Blog = (TextView) view.findViewById(R.id.blog);
        }
    }

//***************************三个必须重载的函数****************************//
    @Override//填充onCreateViewHolder方法返回的holder中的控件
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.useritem, parent, false);
        return new ViewHolder(view);
    }
    @Override
    public void onBindViewHolder(final CardAdapter.ViewHolder holder, final int position) {
        final Github github = githubList.get(position);
        holder.Login.setText(github.getLogin());
        String id = "id："+github.getId();
        holder.Id.setText(id);
        String blog = "blog："+github.getBlog();
        holder.Blog.setText(blog);
        //item的点击事件
        if(mItemClickListener != null) {
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = holder.getLayoutPosition();
                    mItemClickListener.onItemClick(position);
                }
            });
            holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    int position = holder.getLayoutPosition();
                    mItemClickListener.onItemLongClick(position);
                    return true;
                }
            });
        }
    }
    @Override//返回数组的大小
    public int getItemCount() {
        return githubList.size();
    }
//***************************三个必须重载的函数****************************//
    //定义item的回调接口类
    public interface OnItemClickListener
    {
        void onItemClick(int position);
        void onItemLongClick(int position);
    }
    //定义一个设置点击监听的方法
    public void setOnItemClickListener(OnItemClickListener onItemClickListener){
        this.mItemClickListener = onItemClickListener;//设置监听器
    }
}

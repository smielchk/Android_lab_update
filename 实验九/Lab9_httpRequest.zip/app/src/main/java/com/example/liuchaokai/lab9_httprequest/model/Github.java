package com.example.liuchaokai.lab9_httprequest.model;

public class Github {
    private String login;
    private String blog;
    private int id;
    public String getLogin() {
        return login;
    }
    public String getBlog() {
        return blog;
    }
    public int getId() {return id;}
}

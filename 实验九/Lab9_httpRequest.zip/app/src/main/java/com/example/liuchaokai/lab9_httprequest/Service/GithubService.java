package com.example.liuchaokai.lab9_httprequest.Service;

import com.example.liuchaokai.lab9_httprequest.model.Github;
import com.example.liuchaokai.lab9_httprequest.model.Repos;

import java.util.List;
import rx.Observable;

import retrofit2.http.GET;
import retrofit2.http.Path;

//retrofit对象被创建时会传入一个API URL作为参数，然后该对象会“使用”我们指定的 Interface。
// 在这次实验，我们需要用到github的用户数据，因此我们需要传入的 API URL参数就为：
// https://api.github.com，而这个GithubService则是说明，要取到github用户的个人信息和
// 某个github用户的所有仓库信息需要到该URL的哪个“下级目录”去请求数据。


public interface GithubService {
    @GET("/users/{user}")
    Observable<Github> getUser(@Path("user") String user);
    //返回一个 Github 类型

    @GET("/users/{user}/repos")
    Observable<List<Repos>> getRepos(@Path("user") String user);
    //返回一个 List<Repos> 类型
}

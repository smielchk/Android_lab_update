package com.example.liuchaokai.lab9_httprequest.Factory;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

//工厂类通过设置好需要使用到的“产品”，本实验为Retrofit 对象，
// 可以方便的批量生产，即每次需要新建对象时可直接调用里面的函数生成配置好的对象
// ，不必每次都执行相同的代码进行新建对象，省去了配置的过程，从而简化了代码。

//OkHttp 只负责发起网络请求，维护网络连接等操作，
//而Retrofit帮我们将网络传输的数据转换为可用的model对象，并且提供简单的数据处理方式。

public class ServiceFactory {
    //静态成员不属于对象，而属于类。不创建对象也可调用。
    private static OkHttpClient createOkHttp()//创建一个 OkHttpClent 并进行简单配置
    {
        return new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)//连接超时10s
                .readTimeout(30,TimeUnit.SECONDS)//读超时30s
                .writeTimeout(10, TimeUnit.SECONDS)//写超时10s
                .build();
    }

    public static Retrofit createRetrofit(String baseUrl)
    {
        return new Retrofit.Builder()
                .baseUrl(baseUrl)//设置baseUrl
                .addConverterFactory(GsonConverterFactory.create())//添加GSONConverter,数据转换 adapter
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())// rxJava 调用 adapter
                .client(createOkHttp())// client
                .build();
    }
}

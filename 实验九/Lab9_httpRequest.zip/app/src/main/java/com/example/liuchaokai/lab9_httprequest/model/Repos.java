package com.example.liuchaokai.lab9_httprequest.model;

public class Repos {
    private String name;
    private String language;
    private String description;
    public String getName() {
        return name;
    }
    public String getLanguage() {
        return language;
    }
    public String getDescription() {
        return description;
    }
}


//    public Repos(String name, String language, String description)
//    {
//        this.name =name;
//        this.language = language;
//        this.description = description;
//    }
package com.example.liuchaokai.lab9_httprequest.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.liuchaokai.lab9_httprequest.Adapter.CardAdapter;
import com.example.liuchaokai.lab9_httprequest.Factory.ServiceFactory;
import com.example.liuchaokai.lab9_httprequest.R;
import com.example.liuchaokai.lab9_httprequest.Service.GithubService;
import com.example.liuchaokai.lab9_httprequest.model.Github;

import java.util.ArrayList;
import java.util.List;

import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    EditText Search;
    Button Clear, Fetch;
    ProgressBar progressBar;
    RecyclerView recyclerView;

    private CardAdapter cardAdapter;
    private List<Github> githubList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initView();
        Clear.setOnClickListener(this);
        Fetch.setOnClickListener(this);
        SetupAdapter();//item的点击事件
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.clear:
                githubList.clear();
                cardAdapter.notifyDataSetChanged();
                break;
            case R.id.fetch:
                progressBar.setVisibility(View.VISIBLE);
                String Name = Search.getText().toString();
                ServiceFactory.createRetrofit("https://api.github.com/")
                        .create(GithubService.class)
                        .getUser(Name)
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribeOn(Schedulers.newThread())
                        .subscribe(new Subscriber<Github>() {
                            @Override//请求结束时调用的回调函数
                            public void onCompleted() {
                                progressBar.setVisibility(View.GONE);
                            }

                            @Override//请求出现错误时调用的函数
                            public void onError(Throwable e) {
                                Toast.makeText(MainActivity.this, "用户不存在", Toast.LENGTH_SHORT).show();
                                progressBar.setVisibility(View.GONE);
                                e.printStackTrace();
                            }

                            @Override//收到每一次数据时调用的函数
                            public void onNext(Github github) {
                                githubList.add(github);
                                cardAdapter.notifyDataSetChanged();
                            }
                        });
                    break;
                default:break;
        }
    }

    void initView()
    {
        Search = findViewById(R.id.search);
        Clear = findViewById(R.id.clear);
        Fetch = findViewById(R.id.fetch);
        progressBar = findViewById(R.id.progress_bar1);
        recyclerView = findViewById(R.id.user_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        githubList = new ArrayList<>();
        cardAdapter = new CardAdapter(this, githubList);
        recyclerView.setAdapter(cardAdapter);
    }
    void SetupAdapter()
    {
        cardAdapter.setOnItemClickListener(new CardAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                Intent intent = new Intent(MainActivity.this, ReposActivity.class);
                intent.putExtra("login",githubList.get(position).getLogin());
                startActivity(intent);
            }

            @Override
            public void onItemLongClick(int position) {
                githubList.remove(position);
                cardAdapter.notifyDataSetChanged();
            }
        });
    }

}

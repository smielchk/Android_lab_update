package com.example.liuchaokai.lab3_listview_recyclerview;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.RemoteViews;

/**
 * Implementation of App Widget functionality.
 */
public class ShoppingWidget extends AppWidgetProvider {

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);

        //Log.e("tag",intent.getAction());
        if(intent.getAction().equals("com.example.liuchaokai.lab3_listview_recyclerview.STARTAPP"))
        {
            //获取信息
            Bundle gBundle = intent.getExtras();
            int pIcon = gBundle.getInt("pIcon");
            String pTile = gBundle.getString("pTile");
            String pText = gBundle.getString("pText");
            String pName = gBundle.getString("pName");
            Log.d("tag","hihihi111");
            //设置显示内容
            RemoteViews updateViews = new RemoteViews(context.getPackageName(),R.layout.shopping_widget);
            Intent intent1 = new Intent(context,Shopping.class);
            intent1.putExtra("name",pName);

            intent1.addCategory(Intent.CATEGORY_LAUNCHER);

            PendingIntent pi = PendingIntent.getActivity(context,0,intent1,PendingIntent.FLAG_UPDATE_CURRENT);
            updateViews.setImageViewResource(R.id.shopwidget_view,pIcon);
            updateViews.setTextViewText(R.id.shopwidget_text,pText);
            updateViews.setOnClickPendingIntent(R.id.shopwidget,pi);
            ComponentName me = new ComponentName(context,ShoppingWidget.class);
            AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
            appWidgetManager.updateAppWidget(me,updateViews);
        }
        else if(intent.getAction().equals("Order.Product"))
        {
            Bundle gBundle = intent.getExtras();
            int pIcon = gBundle.getInt("pIcon");
            String pTile = gBundle.getString("pTile");
            String pText = gBundle.getString("pText");
            String pName = gBundle.getString("pName");
            //设置显示内容
            RemoteViews updateViews = new RemoteViews(context.getPackageName(),R.layout.shopping_widget);
            Intent intent1 = new Intent(context,MainActivity.class);
            intent1.putExtra("flag",1);

            intent1.addCategory(Intent.CATEGORY_LAUNCHER);

            PendingIntent pi = PendingIntent.getActivity(context,0,intent1,PendingIntent.FLAG_UPDATE_CURRENT);
            updateViews.setImageViewResource(R.id.shopwidget_view,pIcon);
            updateViews.setTextViewText(R.id.shopwidget_text,pText);
            updateViews.setOnClickPendingIntent(R.id.shopwidget,pi);
            ComponentName me = new ComponentName(context,ShoppingWidget.class);
            AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
            appWidgetManager.updateAppWidget(me,updateViews);
        }
    }

    //widget被添加 || 更新时调用
    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        RemoteViews updateViews = new RemoteViews(context.getPackageName(),R.layout.shopping_widget);
        Intent intent = new Intent(context,MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(context,0,intent,PendingIntent.FLAG_UPDATE_CURRENT);
        updateViews.setOnClickPendingIntent(R.id.shopwidget,pi);
        appWidgetManager.updateAppWidget( appWidgetIds ,updateViews);
    }

    //第一个widget被添加调用
    @Override
    public void onEnabled(Context context) {
        // Enter relevant functionality for when the first widget is created
    }


    //最后一个widget被删除时调用
    @Override
    public void onDisabled(Context context) {
        // Enter relevant functionality for when the last widget is disabled
    }
}


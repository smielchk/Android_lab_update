package com.example.liuchaokai.lab8_sql.Activity;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.liuchaokai.lab8_sql.Class.Item;
import com.example.liuchaokai.lab8_sql.Class.MyAdapter;
import com.example.liuchaokai.lab8_sql.Class.MyEventBus;
import com.example.liuchaokai.lab8_sql.R;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;



public class MainActivity extends BaseActivity {

    MyAdapter adapter;//适配器
    private List<Item> itemList = new ArrayList<>();//
    ListView listView;
    Button Add;//添加按钮

    LayoutInflater layoutInflater;
    View view1;
    private TextView Name;
    private EditText Birthday;
    private EditText Gift;
    private TextView Phone;
    private String tname;
    private String tbirthday;
    private String tgift;
    private String tphone;

    private boolean read_contacts;//记录是否赋予权限

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        InitView();//实例化控件
        itemList = query();//初始化itemList
        EventBus.getDefault().register(this);//注册eventbus

        verifyStoragePermission(this);//动态申请权限
        adapter = new MyAdapter(MainActivity.this,R.layout.item,itemList);
        listView.setAdapter(adapter);//设置适配器

        //添加按钮
        Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,AddItem.class);
                if(read_contacts) {
                    startActivity(intent);
                }
            }
        });

        //修改
        listView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, final int position, long id) {
                        view1 = layoutInflater.inflate(R.layout.dialoglayout, null);
                        Name = (TextView) view1.findViewById(R.id.d_name);
                        Birthday = (EditText) view1.findViewById(R.id.d_birthday);
                        Gift = (EditText) view1.findViewById(R.id.d_gift);
                        Phone = (TextView) view1.findViewById(R.id.phone);
                        final Item item = itemList.get(position);
                        tname = item.getName();
                        tbirthday = item.getBirthday();
                        tgift = item.getGift();
                        tphone = item.getPhone();

                        Name.setText(tname);
                        Birthday.setText(tbirthday);
                        Gift.setText(tgift);
                        Phone.setText(tphone);

                        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
                        alertDialog.setView(view1);
                        alertDialog.setTitle("ヽ(*￣∀￣)ノ~★恭喜发财★~ヽ`");
                        alertDialog.setPositiveButton("保存修改", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                tname = Name.getText().toString();
                                tbirthday = Birthday.getText().toString();
                                tgift = Gift.getText().toString();

                                update(tname, tbirthday, tgift);//更新数据库
                                itemList.get(position).setBirthday(tbirthday);
                                itemList.get(position).setGift(tgift);
                                adapter.notifyDataSetChanged();
                            }
                        });
                        alertDialog.setNegativeButton("放弃修改", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                            }
                        });
                        alertDialog.show();
                    }
                }
        );

        //删除
        listView.setOnItemLongClickListener(
                new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(final AdapterView<?> adapterView, View view, final int position, long id) {
                       final  Item item = itemList.get(position);
                       final AlertDialog.Builder deleteDialog = new AlertDialog.Builder(MainActivity.this);
                       deleteDialog.setMessage("是否删除");
                       deleteDialog.setPositiveButton("是", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialogInterface, int i) {
                               delete(item.getName());
                               itemList.remove(position);
                               adapter.notifyDataSetChanged();
                           }
                       });
                       deleteDialog.setNegativeButton("否", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialogInterface, int i) {
                           }
                       });
                       deleteDialog.show();
                       return true;
                    }
                }
        );
    }

    void InitView()
    {
        Add = (Button) findViewById(R.id.add);
        listView = (ListView) findViewById(R.id.list_item);
        layoutInflater = LayoutInflater.from(MainActivity.this);
    }

    //动态申请权限
    private void verifyStoragePermission(Activity activity)
    {
        try {
            int permission = ActivityCompat.checkSelfPermission(activity,
                    "android.permission.READ_CONTACTS");
            if(permission != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(activity, new String[]
                        {Manifest.permission.READ_CONTACTS},1);
            }
            else {
                read_contacts = true;//记录可读可写内存卡
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            read_contacts = true;
        }
        else {
            System.exit(0);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);//反注册EventBus
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(MyEventBus event)
    {
        Item item = event.getItem();
        itemList.add(item);
        adapter.notifyDataSetChanged();//更新数据
    }
}

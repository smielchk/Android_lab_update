package com.example.liuchaokai.lab8_sql.Activity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.liuchaokai.lab8_sql.Class.Item;
import com.example.liuchaokai.lab8_sql.Class.MyDB;
import com.example.liuchaokai.lab8_sql.R;

import java.util.ArrayList;
import java.util.List;

public class BaseActivity extends AppCompatActivity {
    private MyDB db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base);
        db = new MyDB(this,"Items.db", null, 2);
        db.getWritableDatabase();//创建数据库
    }

    public void insert(String name, String birthday, String gift, String phone) {
        SQLiteDatabase database = db.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("birthday", birthday);
        values.put("gift", gift);
        values.put("phone", phone);
        database.insert("Item", null, values);
        values.clear();
    }

    public void update(String name, String birthday, String gift) {
        SQLiteDatabase database = db.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("birthday", birthday);
        values.put("gift", gift);
        database.update("Item", values, "name = ?", new String[] {name});
    }

    public void delete(String name) {
        SQLiteDatabase database = db.getWritableDatabase();
        database.delete("Item", "name = ?", new String[]{name});
    }

    public boolean query(String fname) //传入名字，查看是否重名，返回值为bool类型
    {
        boolean flag = true;
        SQLiteDatabase database = db.getWritableDatabase();
        Cursor cursor = database.query("Item", null,
                null, null, null, null, null);
        if(cursor.moveToFirst())
        {
            do {
                String name = cursor.getString(cursor.getColumnIndex("name"));
                if(name.equals(fname)) {
                    flag = false;
                    break;
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return flag;
    }

    public List<Item> query() //返回数据库的所有信息。
    {
        List<Item> itemList = new ArrayList<>();
        SQLiteDatabase database = db.getWritableDatabase();
        Cursor cursor = database.query("Item", null,
                null, null, null, null, null);
        if(cursor.moveToFirst())
        {
            do {
                String name = cursor.getString(cursor.getColumnIndex("name"));
                String birthday = cursor.getString(cursor.getColumnIndex("birthday"));
                String gift = cursor.getString(cursor.getColumnIndex("gift"));
                String phone = cursor.getString(cursor.getColumnIndex("phone"));
                itemList.add(new Item(name, birthday, gift, phone));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return itemList;
    }
}

package com.example.liuchaokai.lab8_sql.Class;

import com.example.liuchaokai.lab8_sql.Class.Item;

public class MyEventBus {

    private Item item;
    public MyEventBus(Item item)
    {
        this.item = item;
    }
    public Item getItem(){
        return item;
    }
}

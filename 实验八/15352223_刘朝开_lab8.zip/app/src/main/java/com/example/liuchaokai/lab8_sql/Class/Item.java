package com.example.liuchaokai.lab8_sql.Class;



public class Item {
    private String name;
    private String birthday;
    private String gift;
    private String phone;

    public Item(String name, String birthday, String gift, String phone)
    {
        this.name = name;
        this.birthday = birthday;
        this.gift = gift;
        this.phone = phone;
    }
    public String getName(){
        return name;
    }
    public String getBirthday()
    {
        return birthday;
    }
    public String getGift()
    {
        return gift;
    }
    public String getPhone() {
        return phone;
    }
    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }
    public void setGift(String gift) {
        this.gift = gift;
    }
    public void setPhone(String phone){
        this.phone = phone;
    }
}

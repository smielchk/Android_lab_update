package com.example.liuchaokai.lab8_sql.Activity;

import android.database.Cursor;
import android.provider.ContactsContract;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.liuchaokai.lab8_sql.Class.Item;
import com.example.liuchaokai.lab8_sql.Class.MyEventBus;
import com.example.liuchaokai.lab8_sql.R;

import org.greenrobot.eventbus.EventBus;

public class AddItem extends BaseActivity {
    EditText [] editTexts = new EditText[3];
    String getText[] = new String[3];
    Button add;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);
        InitView();
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for (int i=0; i<3;i++) {
                    getText[i] = editTexts[i].getText().toString();
                }
                if (getText[0].equals("")){
                    Toast.makeText(AddItem.this, "名字为空，请完善", Toast.LENGTH_SHORT).show();
                }
                else {
                    boolean flag = query(getText[0]);//用来记录是否有重复
                    if(flag) {
                        String phone = readContacts(getText[0]);//读取联系电话
                        insert(getText[0], getText[1], getText[2],phone);
                        Item item = new Item(getText[0], getText[1], getText[2],phone);
                        EventBus.getDefault().post(new MyEventBus(item));
                        finish();
                    }
                    else {
                        Toast.makeText(AddItem.this, "名字重复，请检查", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
    void InitView()
    {
        add = (Button) findViewById(R.id.additem);
        editTexts[0] = (EditText) findViewById(R.id.ename);
        editTexts[1] = (EditText) findViewById(R.id.ebirthday);
        editTexts[2] = (EditText) findViewById(R.id.egift);
    }

    //内容提供器,读取联系人电话
    private String readContacts(String name) {
        String phone = "无";
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    null, null, null, null);
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    String displayName = cursor.getString(cursor.getColumnIndex//获取联系人姓名
                            (ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                    String number = cursor.getString(cursor.getColumnIndex//获取联系人号码
                            (ContactsContract.CommonDataKinds.Phone.NUMBER));
                    if(displayName.equals(name)) {
                        phone = number;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return phone;
    }
}

package com.example.liuchaokai.lab3_listview_recyclerview;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import static java.security.AccessController.getContext;


public class Shopping extends AppCompatActivity {

    private int pImages [] ={R.drawable.enchatedforest,R.drawable.arla,R.drawable.devondale,
    R.drawable.kindle,R.drawable.waitrose,R.drawable.mcvitie,R.drawable.ferrero,R.drawable.maltesers,
    R.drawable.lindt,R.drawable.borggreve};
    private String pNames [] = {"Enchated Forest","Arla Milk","Devondale Milk",
            "Kindle Oasis","waitrose 早餐麦片","Mcvitie's 饼干","Ferreo Rocher",
            "Maltesers","Lindt","Borggreve"};
    private String pPrice [] = {"¥5.00","¥59.00","¥79.00","¥2399.00","¥179.00", "¥14.90",
            "¥132.59","¥141.43","¥139.43","¥28.90"};
    private String pInformation [] = {"作者    Johanna Basford","产地    德国","产地    澳大利亚","版本    8GB"
,    "重量    2Kg","产地    英国","重量    300g","重量    118g","重量    249g","重量    640g"};

    private String mInformation [] = {"一键下单","分享商品","不感兴趣","查看更多商品促销信息"};

    private ImageView PImage;
    private TextView Nameview;
    private TextView Priceview;
    private TextView Information;
    private ImageView Back;
    private ImageView Star;
    private ImageView sCar;

    private int flag = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping);

        PImage = (ImageView) findViewById(R.id.productImage);
        Nameview = (TextView) findViewById(R.id.productName);
        Priceview = (TextView) findViewById(R.id.Price);
        Information = (TextView) findViewById(R.id.version);

        final Intent intent = getIntent();
        final String sname = intent.getStringExtra("name");
        int snumber = SelectNumer(sname)-1;
        PImage.setImageResource(pImages[snumber]);
        Nameview.setText(pNames[snumber]);
        Priceview.setText(pPrice[snumber]);
        Information.setText(pInformation[snumber]);

        Back = (ImageView) findViewById(R.id.back);
        Star = (ImageView) findViewById(R.id.star);
        sCar = (ImageView) findViewById(R.id.scar);

        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        Star.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(flag == 1)
                {
                    Star.setImageResource(R.drawable.empty_star);
                    flag = 0;
                }
                else {
                    Star.setImageResource(R.drawable.full_star);
                    flag = 1;
                }
            }
        });
        sCar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Shopping.this,"商品已加到购物车",Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent();
                String Name = Nameview.getText().toString();
                int return_data = SelectNumer(Name);
                intent1.putExtra("data_return",return_data);
                setResult(RESULT_OK,intent1);
            }
        });
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(
                Shopping.this,android.R.layout.simple_list_item_1,mInformation);
        ListView listView = (ListView) findViewById(R.id.mInformation);
        listView.setAdapter(arrayAdapter);
    }
    private int SelectNumer(String sName)
    {
        int return_data = 1;
        switch(sName)
        {
            case "Enchated Forest":
                return_data=1;break;
            case "Arla Milk":
                return_data=2;break;
            case "Devondale Milk":
                return_data=3;break;
            case "Kindle Oasis":
                return_data=4;break;
            case "waitrose 早餐麦片":
                return_data=5;break;
            case "Mcvitie's 饼干":
                return_data=6;break;
            case "Ferreo Rocher":
                return_data=7;break;
            case "Maltesers":
                return_data=8;break;
            case "Lindt":
                return_data=9;break;
            case "Borggreve":
                return_data=10;break;
        }
        return return_data;
    }
}

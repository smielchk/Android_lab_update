package com.example.liuchaokai.lab3_listview_recyclerview;


public class Products
{
    private String fletter;
    private String name;
    private String price;

    public Products(String fletter,String name,String price)
    {
        this.fletter = fletter;
        this.name = name;
        this.price = price;
    }
    public  String getFletter(){return fletter;}
    public String getName() {return name;}
    public String getPrice() {return price;}
}

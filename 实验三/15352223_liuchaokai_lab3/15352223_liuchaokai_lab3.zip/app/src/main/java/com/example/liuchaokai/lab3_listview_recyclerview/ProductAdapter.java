package com.example.liuchaokai.lab3_listview_recyclerview;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ViewHolder>
{
    private List<Products> mProductList;
    private Context mContext;
    private LayoutInflater inflater;
    private OnItemClickListener mItemClickListener;

    //类构造函数
    public ProductAdapter(Context context,List<Products> productsList)
    {
        this.mContext = context;
        this.mProductList = productsList;
        inflater = LayoutInflater.from(mContext);
        mItemClickListener = null;
    }

    // 定义内部类继承RecyclerView.ViewHolder
    static class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView pfletter;
        TextView pname;
        //TextView pprice;

        public ViewHolder(View view)
        {
            super(view);
            pfletter = (TextView) view.findViewById(R.id.firstletter);
            pname = (TextView) view.findViewById(R.id.productname);
            //pprice = (TextView) view.findViewById(R.id.price);
        }
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.product,parent,false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    //填充onCreateViewHolder方法返回的holder中的控件
    @Override
    public void onBindViewHolder(final ViewHolder holder,int position)
    {
        final Products product = mProductList.get(position);
        holder.pfletter.setText(product.getFletter());
        holder.pname.setText(product.getName());
        //holder.pprice.setText(product.getPrice());


        if(mItemClickListener != null)//判断是否设置了监听器
        {
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = holder.getLayoutPosition();
                    mItemClickListener.onItemClick(position);
                }
            });

            holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    int position = holder.getLayoutPosition();
                    mItemClickListener.onItemLongClick(position);
                    return true;
                }
            });
        }
    }


    @Override
    public int getItemCount() {
        return mProductList.size();
    }

    //定义item的回调接口类
    public interface OnItemClickListener
    {
        void onItemClick(int position);
        void onItemLongClick(int position);
    }
    //定义一个设置点击监听的方法
    public void setOnItemClickListener(OnItemClickListener onItemClickListener){
        this.mItemClickListener = onItemClickListener;
    }

}

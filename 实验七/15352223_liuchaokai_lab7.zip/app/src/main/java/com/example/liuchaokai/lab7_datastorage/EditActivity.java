package com.example.liuchaokai.lab7_datastorage;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class EditActivity extends AppCompatActivity implements View.OnClickListener{

    Button[] buttons = new Button[4];
    EditText title_editText, content_editText;
    String fileName, fileContent;//标题和内容

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        initView();//初始化实例
        for(int i=0;i<4;i++)//按钮
        {
            buttons[i].setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.save:
                fileName = title_editText.getText().toString();
                if (fileName.contains("/")) {
                    Toast.makeText(this, "Invilid file name!", Toast.LENGTH_SHORT).show();
                }
                else {
                    fileContent = content_editText.getText().toString();
                    save(fileName, fileContent);
                }
                break;
            case R.id.load:
                fileName = title_editText.getText().toString();
                fileContent=load(fileName);
                content_editText.setText(fileContent);
                break;
            case R.id.clear:
                content_editText.setText("");
                break;
            case R.id.delete:
                fileName = title_editText.getText().toString();
                boolean flag = deleteFile(fileName);
                if(flag) Toast.makeText(EditActivity.this,"Delete successfully",Toast.LENGTH_SHORT).show();
                else Toast.makeText(this, "There is no such file", Toast.LENGTH_SHORT).show();
                break;
            default:break;
        }
    }

    //以下为个人定义函数
    private void initView()//初始化实例
    {
        buttons[0] = (Button) findViewById(R.id.save);
        buttons[1] = (Button) findViewById(R.id.load);
        buttons[2] = (Button) findViewById(R.id.clear);
        buttons[3] = (Button) findViewById(R.id.delete);
        title_editText = (EditText) findViewById(R.id.edit_title);
        content_editText = (EditText) findViewById(R.id.edit_content);
    }
    private void save(String fileName, String fileContent)//保存文件，传入文件名和文件内容
    {
        FileOutputStream out = null;
        BufferedWriter writer = null;
        try {
            out = openFileOutput(fileName, Context.MODE_PRIVATE);
            writer = new BufferedWriter(new OutputStreamWriter(out));
            writer.write(fileContent);
            Toast.makeText(EditActivity.this,"Save successfully",Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(EditActivity.this,"Fail to save file",Toast.LENGTH_SHORT).show();

        }finally {
            try {
                if(writer!=null) {
                    writer.close();
                }
            }catch (IOException e){
                e.printStackTrace();
            }
        }
    }
    private String load(String fileName)//加载文件，传入文件名，返回文件内容
    {
        FileInputStream in = null;
        BufferedReader reader = null;
        StringBuilder content = new StringBuilder();
        try {
            in = openFileInput(fileName);
            reader = new BufferedReader(new InputStreamReader(in));
            String line = "";
            while ((line = reader.readLine())!=null){
                content.append(line);
            }
            Toast.makeText(EditActivity.this,"Load successfully",Toast.LENGTH_SHORT).show();
        }catch (IOException e){
            e.printStackTrace();
            Toast.makeText(EditActivity.this,"Fail to load file",Toast.LENGTH_SHORT).show();
        }finally {
            if(reader != null){
                try{
                    reader.close();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        }
        return content.toString();
    }
}

package com.example.liuchaokai.lab7_datastorage;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button OK, Clear;
    EditText [] editTexts = new EditText[4];
    boolean isFirstin = true;//记录是否第一次打开app
    String Npassword,Cpassword,password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();//实例化
        SharedPreferences preferences = getSharedPreferences("data",MODE_PRIVATE);
        isFirstin = preferences.getBoolean("isFirstin",true);
        setUI();
        Npassword = preferences.getString("Npassword","");
        //Toast.makeText(MainActivity.this,Npassword,Toast.LENGTH_SHORT).show();
        OK.setOnClickListener(this);//点击事件
        Clear.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.ok:
                if(isFirstin) {
                    Npassword = editTexts[0].getText().toString();
                    Cpassword = editTexts[1].getText().toString();
                    if(Npassword.equals("") || Cpassword.equals("")) {
                        Toast.makeText(MainActivity.this,"Password cannot be empty",Toast.LENGTH_SHORT).show();
                    }
                    else if(!Npassword.equals(Cpassword)) {
                        Toast.makeText(MainActivity.this,"Password Mismatch",Toast.LENGTH_SHORT).show();
                    }
                    else {
                        isFirstin = false;
                        setUI();
                        SharedPreferences.Editor editor = getSharedPreferences("data",MODE_PRIVATE).edit();
                        editor.putBoolean("isFirstin",false);
                        editor.putString("Npassword",Npassword);
                        editor.apply();//提交，将isFirstIn设为false
                    }
                }
                else
                {
                    password = editTexts[2].getText().toString();
                    if(password.equals(Npassword)){
                        Intent intent = new Intent(MainActivity.this,EditActivity.class);
                        startActivity(intent);
                        finish();
                    }
                    else {
                        Toast.makeText(MainActivity.this,"Password Mismatch",Toast.LENGTH_SHORT).show();
                    }
                }
                break;
            case R.id.clear:
                if(isFirstin){
                    editTexts[0].setText("");
                    editTexts[1].setText("");
                }
                else {
                    editTexts[2].setText("");
                }
                break;
            default:break;
        }
    }

    void initView()//初始化实例
    {
        OK = (Button) findViewById(R.id.ok);
        Clear = (Button) findViewById(R.id.clear);
        editTexts[0] = (EditText) findViewById(R.id.Npassword);
        editTexts[1] = (EditText) findViewById(R.id.Cpassword);
        editTexts[2] = (EditText) findViewById(R.id.password);
    }
    void setUI()//设置界面
    {
        if(isFirstin) {
            editTexts[0].setVisibility(View.VISIBLE);
            editTexts[1].setVisibility(View.VISIBLE);
            editTexts[2].setVisibility(View.INVISIBLE);
        }
        else {
            editTexts[0].setVisibility(View.INVISIBLE);
            editTexts[1].setVisibility(View.INVISIBLE);
            editTexts[2].setVisibility(View.VISIBLE);
        }
    }
}

package com.example.liuchaokai.lab6service_and_thread;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Parcel;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.support.v4.app.ActivityCompat;
import android.widget.Toast;

import java.text.SimpleDateFormat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private Button [] buttons = new Button[4];
    private TextView [] textViews = new TextView[4];
    private ImageView imageView;
    private SeekBar seekBar;
    private static String state = "start";//记录音乐播放状态
    Intent Musicintent;//音乐服务
    private static ObjectAnimator animator;
    private IBinder musicBinder;
    private static boolean isrwsdcard = false;//记录是否赋予读写sd卡的权限
    private boolean seekbarchange = false;
    @SuppressLint("SimpleDateFormat")
    private SimpleDateFormat time = new SimpleDateFormat("mm:ss");
    Thread thread;
    private static Handler handler;

    private int code;
    private Parcel data;
    private Parcel reply;

    //连接
    private ServiceConnection connection = new ServiceConnection() {
        @Override// 通过IBinder获取Service对象,实现Activity与Service的绑定
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            musicBinder = iBinder;
        }
        @Override// 解除绑定
        public void onServiceDisconnected(ComponentName componentName) {
            musicBinder = null;
        }
    };


    @SuppressLint("HandlerLeak")
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,// 隐藏状态栏
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        initView();
        verifyStoragePermission(this);//动态申请权限

        if(isrwsdcard && musicBinder==null) {
            Musicintent = new Intent(this,MusicService.class);
            startService(Musicintent);
            bindService(Musicintent,connection,BIND_AUTO_CREATE);//绑定服务
        }

        buttons[0].setOnClickListener(this);
        buttons[1].setOnClickListener(this);
        buttons[2].setOnClickListener(this);
        //图片旋转动画
        animator = ObjectAnimator.ofFloat(imageView, "rotation", 0f, 359f);
        LinearInterpolator interpolator = new LinearInterpolator();//线性
        animator.setInterpolator(interpolator);//设置匀速旋转，在xml文件中设置会出现卡顿
        animator.setDuration(60000);
        animator.setRepeatCount(-1);

        handler = new Handler()//线程控制UI
        {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                switch (msg.what) {
                    case 1:
                        Log.d("happpy","happpy");
                        code = 104;
                        data = Parcel.obtain();
                        reply = Parcel.obtain();
                        try {
                            musicBinder.transact(code,data,reply,0);
                        }catch (RemoteException e) {
                            e.printStackTrace();
                        }
                        reply.setDataPosition(0);
                        int getCposition = reply.readInt();
                        reply.setDataPosition(4);
                        int getDuratin = reply.readInt();
                        if(isrwsdcard && !seekbarchange) {
                            textViews[1].setText(time.format(getCposition));
                            textViews[2].setText(time.format(getDuratin));
                            seekBar.setProgress(getCposition);
                            seekBar.setMax(getDuratin);
                        }
                        initUI();

                        break;
                    default:break;
                }
            }
        };

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                seekbarchange = true;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                seekbarchange = false;
                code = 105;
                data = Parcel.obtain();
                data.writeInt(seekBar.getProgress());
                reply = Parcel.obtain();
                try {
                    musicBinder.transact(code,data,reply,0);
                }catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        });

        thread = new Thread()
        {
            @Override
            public void run() {
                while(true)
                {
                    try {
                        Thread.sleep(100);
                    }catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    if(connection!=null && musicBinder!=null)
                    {
                        Message message = new Message();
                        message.what = 1;
                        handler.sendMessage(message);
                    }
                }
            }
        };
        thread.start();//开启线程
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.play:
                code = 101;
                data = Parcel.obtain();
                reply = Parcel.obtain();
                sendMessage(code,data,reply,0);
                reply.setDataPosition(0);
                state = reply.readString();
                break;
            case R.id.stop:
                code = 102;
                data = Parcel.obtain();
                reply = Parcel.obtain();
                sendMessage(code,data,reply,0);
                reply.setDataPosition(0);
                state = reply.readString();
                break;
            case R.id.quit:
                code = 103;
                data = Parcel.obtain();
                reply = Parcel.obtain();
                sendMessage(code,data,reply,0);
                unbindService(connection);
                try{
                    finish();
                    System.exit(0);
                }catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            default:break;
        }
    }

    //动态申请权限
    private void verifyStoragePermission(Activity activity)
    {
        try {
            int permission = ActivityCompat.checkSelfPermission(activity,
                    "android.permission.READ_EXTERNAL_STORAGE"
            );
            if(permission != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(activity, new String[]
                        {Manifest.permission.READ_EXTERNAL_STORAGE},1);
            }
            else {
                isrwsdcard = true;//记录可读可写内存卡
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            isrwsdcard = true;
        }
        else {
            System.exit(0);
        }
    }
    private void initView()
    {
        buttons[0] = (Button) findViewById(R.id.play);
        buttons[1] = (Button) findViewById(R.id.stop);
        buttons[2] = (Button) findViewById(R.id.quit);
        textViews[0] = (TextView) findViewById(R.id.state);
        textViews[1] = (TextView) findViewById(R.id.stime);
        textViews[2] = (TextView) findViewById(R.id.etime);
        imageView = (ImageView) findViewById(R.id.image);
        seekBar = (SeekBar) findViewById(R.id.seektime);
    }
    private void initUI() {
        switch (state) {
            case "start":
                textViews[0].setText(null);
                buttons[0].setText("PLAY");
                break;
            case "play":
                buttons[0].setText("PAUSED");
                textViews[0].setText("Playing");

                if(!animator.isStarted() && !animator.isRunning()) {
                    animator.start();
                    Log.e("tag","startajksl");
                }
                else if(animator.isPaused()){
                    animator.resume();
                }
                break;
            case "pause":
                buttons[0].setText("PLAY");
                textViews[0].setText("Paused");
                animator.pause();
                break;
            case "stop":
                textViews[0].setText("Stopped");
                buttons[0].setText("PLAY");
                animator.end();
                break;
            default:break;
        }
    }
    private void sendMessage(int code, Parcel data, Parcel reply, int flag)//发送信息
    {
        try {
            musicBinder.transact(code,data,reply,0);
        }catch (RemoteException e) {
            e.printStackTrace();
        }
    }
//    @Override//重写back键，实现Home效果
//    public void onBackPressed() {
//        Intent intent = new Intent(Intent.ACTION_MAIN);
//        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        intent.addCategory(Intent.CATEGORY_HOME);
//        startActivity(intent);
//    }
}

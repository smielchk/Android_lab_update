package com.example.liuchaokai.lab6service_and_thread;

import android.animation.ObjectAnimator;
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Environment;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.Toast;

public class MusicService extends Service {

    private MediaPlayer mp = new MediaPlayer();
    String curState = "";//记录当前状态
    public final MusicBinder mBinder = new MusicBinder();// 通过Binder来保持Activity和Service的通信
    public class  MusicBinder extends Binder {
        @Override
        protected boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            switch (code) {
                case 101://播放按钮，服务处理函数
                    playMusic();
                    reply.writeString(curState);
                    break;
                case 102://停止按钮服务处理函数
                    stopMusic();
                    reply.writeString(curState);
                    break;
                case 103://退出按钮，服务处理函数
                    stopMusic();
                    reply.writeString(curState);
                    break;
                case 104://界面刷新，服务返回数据函数
                    int mpCposition = mp.getCurrentPosition();
                    int mpDuration = mp.getDuration();
                    reply.writeInt(mpCposition);
                    reply.writeInt(mpDuration);
                    reply.writeString(curState);
                    break;
                case 105://拖动进度条，服务处理函数
                    mp.seekTo(data.readInt());
                    break;
                default:break;
            }
            return super.onTransact(code,data,reply,flags);
        }
        public MusicService getService() {
            return MusicService.this;
        }
    }
    public MusicService() {
        try{
            String filePath = Environment.getExternalStorageDirectory().getAbsolutePath()+"/Music/melt.mp3";
            mp.setDataSource(filePath);
            mp.prepare();
            mp.seekTo(0);
            mp.setLooping(true);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

//    @Override
//    public int onStartCommand(Intent intent, int flags, int startId) {
//
//        return START_STICKY;
//    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mp.stop();
        mp.release();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }
    public  void playMusic(){
        if(mp != null) {
            if(mp.isPlaying()) {
                mp.pause();
                curState = "pause";
            }
            else {
                try {
                    mp.start();
                    curState = "play";
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
    }
    public void stopMusic() {
        if(mp != null){
            mp.stop();
            curState = "stop";
            try {
                mp.prepare();
                mp.seekTo(0);
            }catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}
